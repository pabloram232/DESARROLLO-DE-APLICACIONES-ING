from setuptools import setup

setup(
    name='energia_module',
    version='1.0',
    description='Obtencion de la energia atravez de su formula',
    author='JPR',
    author_email='pablo.ram232@gmail.com',
    url='trello.com/pa',
    py_modules=['energia_module'],
)
