def energia(L:float,M:float,T:float)->float:
    energia=(L**2)*(M)*(T**-2)
    return energia


def potencia(L:float,M:float,T:float)->float:
    potencia=(L**2)*(M)*(T**-3)
    return potencia

